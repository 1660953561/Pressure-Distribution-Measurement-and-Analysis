# FIXED

main.obj: ../main.c
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp432p401r.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp_compatibility.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp432p401r_classic.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/core_cm4.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/system_msp432p401r.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h
main.obj: D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h

../main.c:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp432p401r.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp_compatibility.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/msp432p401r_classic.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/core_cm4.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/ccs_base/arm/include/system_msp432p401r.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdio.h:

D:/software/Learning\ software/MSP432\ for\ TI/CCS/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdarg.h:

